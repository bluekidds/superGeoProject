//
//  ARSecondeViewController.m
//  III_AR_Navigation
//
//  Created by Chun F.Hsu on 2010/4/9.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "ARSecondeViewController.h"


@implementation ARSecondeViewController
@synthesize myMap2;
@synthesize locManager;

@synthesize myPointArray;
//@synthesize place1;
//@synthesize mylocationtest;
/*
 // The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    if (self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil]) {
        // Custom initialization
    }
    return self;
}
*/
-(void)locationManager:(CLLocationManager *)manager didUpdateToLocation:(CLLocation *)newLocation fromLocation:(CLLocation *)oldLocation
{
	
	//updatedLocation = newLocation.coordinate; //newlocation -> user's current location.
	
	[myMap2 setCenterCoordinate:newLocation.coordinate animated:YES];
	
	
	
	//region2.center = newLocation.coordinate;
	
	//MKCoordinateRegion updateRegion;
	
	//updateRegion.center = updatedLocation;
    //MKCoordinateSpan span;
	
	//span.latitudeDelta=.001;
	//span.longitudeDelta=.001;
	//updateRegion.span=span;	
	//[myMap2 setRegion:updateRegion animated:YES];
	
	//[myMap2 setRegion:region2 animated:YES];
	
	//	myMap.region = updateRegion;
	//	MKCoordinateRegion zoomOut = { { newLocation.coordinate.latitude , newLocation.coordinate.longitude }, {4, 4} };
	//	[myMap setRegion:zoomOut animated:YES];
	//	myMap.region.center= newLocation.coordinate; 
	//	myMap.region.span = {newLocation.horizontalAccuracy,newLocation.verticalAccuracy};
	
	//[myMap setRegion:zoomOut  animated:YES];
	//	[self.view setNeedsDisplay];
    //myMap.centerCoordinate = newLocation.coordinate;	
}

-(BOOL)settingLocationManager
{
	//First we will start heading service
	self.locManager = [[[CLLocationManager alloc] init] autorelease];
	//locManager.headingFilter = kCLHeadingFilterNone;	
	//locManager.distanceFilter = kCLLocationAccuracyBest;
	// setup delegate callbacks
	locManager.delegate = self;
	// start the compass
	//[locManager startUpdatingHeading];
	[locManager startUpdatingLocation];	//update the user's current location -> didUpdateToLocation
	return YES;
}

- (MKAnnotationView *)mapView:(MKMapView *)theMapView viewForAnnotation:(id <MKAnnotation>)annotation
{
	NSLog(@"annotationview");
	if ([annotation isKindOfClass:[SFAnnotation class]])   // for City of San Francisco
    {
		MKAnnotationView *annotationView = [[[MKAnnotationView alloc] initWithAnnotation:annotation reuseIdentifier:@"imagetest1"]autorelease];
		annotationView.canShowCallout = YES;
		
		UIImage *flagImage = [UIImage imageNamed:@"flag.png"];
		annotationView.image = flagImage;
		annotationView.opaque = NO;
		NSLog(@"annotationview2");
		
		/*             
		 CGRect resizeRect;
		 
		 resizeRect.size = flagImage.size;
		 CGSize maxSize = CGRectInset(self.view.bounds,
		 [MapViewController annotationPadding],
		 [MapViewController annotationPadding]).size;
		 maxSize.height -= self.navigationController.navigationBar.frame.size.height + [MapViewController calloutHeight];
		 if (resizeRect.size.width > maxSize.width)
		 resizeRect.size = CGSizeMake(maxSize.width, resizeRect.size.height / resizeRect.size.width * maxSize.width);
		 if (resizeRect.size.height > maxSize.height)
		 resizeRect.size = CGSizeMake(resizeRect.size.width / resizeRect.size.height * maxSize.height, maxSize.height);
		 
		 resizeRect.origin = (CGPoint){0.0f, 0.0f};
		 UIGraphicsBeginImageContext(resizeRect.size);
		 [flagImage drawInRect:resizeRect];
		 UIImage *resizedImage = UIGraphicsGetImageFromCurrentImageContext();
		 UIGraphicsEndImageContext();
		 
		 annotationView.image = resizedImage;
		 annotationView.opaque = NO;
		 */			
		UIImageView *sfIconView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"SFIcon.png"]];
		annotationView.leftCalloutAccessoryView = sfIconView;
		[sfIconView release];
		
		return annotationView;
		
	}
	return nil;
}

//issac 0504 for map point
- (void)/*(SFAnnotation *)*/ createMapPoint:(MKMapView *)mapView coordinateX:(double)coorX coordinateY:(double)coorY
						   Title:(NSString*)title Subtitle:(NSString*)subtitle
{
	if(mapView!=nil){

		//set POI lat and lng
		CLLocationCoordinate2D p1;
		//SFAnnotation *poi = [[SFAnnotation alloc] init ];
		SFAnnotation *poi;
		if(coorX && coorY){
			
			p1.latitude=coorX;
			p1.longitude = coorY;
			poi = [[SFAnnotation alloc] initWithCoords:p1]; 
			//[poi initWithCoords:p1];
			if(title!=NULL)
				poi.title=title;
			
			if(subtitle!=NULL)
				poi.subtitle=subtitle;
			
			//[mapView addAnnotation:poi];
			[self.myMap2 addAnnotation:poi];
			NSLog(@"createMappoint!");
			[poi release];
			
		}
		//return poi;
	}
	//return nil;
}	

- (void)setMyPoint
{
	/*	CLLocationCoordinate2D p1;
	 p1.latitude = 25.063546878877353;
	 p1.longitude = 121.55214657064167;
	 CLLocationCoordinate2D p2;
	 p2.latitude = 25.054896374127832;
	 p2.longitude = 121.55742009489931;
	 */	
	/*	[self createMapPoint:myMap2 
	 coordinateX:<#(double)coorX#> 
	 coordinateY:<#(double)coorY#> 
	 Title:<#(NSString *)title#> 
	 Subtitle:<#(NSString *)subtitle#>];
	 */
	//SFAnnotation place[10];
/*	
 {"台北 101 "      , 25.033492284074082, 121.56422018047304, 0, 0}, *
 {"松山機場 "      , 25.063546878877353, 121.55214657064167, 0, 0},*
 {"台朔大樓 "      , 25.056658542397958, 121.54969738657833, 0, 0},
 {"京華城 "        , 25.047693297937872, 121.56186702154896, 0, 0},
 {"松山醫院 "      , 25.054896374127832, 121.55742009489931, 0, 0},*
 {"捷運中山國中站 ", 25.060939860674153, 121.54424535064861, 0, 0},
 {"美麗華 "        , 25.083754775873032, 121.55733263292502, 0, 0}}*
 
 wego (25.083606928081835, 121.55574917793274)*
 典華 (25.083606928081835, 121.55574917793274)*
 台北戀館 (25.082994755492088, 121.55490159988403)
 家樂福 (25.08228540882096, 121.55800223350525)*
 維多利亞酒店 (25.08416079588206, 121.55746579170227)*
 國防部史政編輯室 (25.08548229489565, 121.55490159988403)
 捷運劍南路站 (25.084850697882406, 121.55558824539185)*
 
 大直捷運站 (25.07953543698054, 121.54685497283936)
 西湖捷運站 (25.082139652146584, 121.5671968460083)
 圓山大飯店 (25.078602570310615, 121.52626633644104)*
 大佳河濱公園 (25.07510425699454, 121.5304183959961)
 兒童育樂中心 (25.073393934108477, 121.52217864990234)
*/
	NSLog(@"point");
	[self createMapPoint:myMap2 
					  coordinateX:25.063546878877353 
					  coordinateY:121.55214657064167 
							Title:@"松山機場" 
						 Subtitle:@"飛航國內與兩岸航班"];
	[self createMapPoint:myMap2 
					  coordinateX:25.054896374127832 
					  coordinateY:121.55742009489931 
							Title:@"松山醫院" 
						 Subtitle:@"醫院"];
	[self createMapPoint:myMap2 
					  coordinateX:25.033492284074082 
					  coordinateY:121.56422018047304 
							Title:@"台北 101" 
						 Subtitle:@"世界第二高樓"];
	[self createMapPoint:myMap2 
					  coordinateX:25.083754775873032 
					  coordinateY:121.55733263292502 
							Title:@"美麗華" 
						 Subtitle:@"摩天輪 IMAX影城"];
	[self createMapPoint:myMap2 
					  coordinateX:25.083606928081835 
					  coordinateY:121.55574917793274 
							Title:@"典華婚宴會場" 
						 Subtitle:@"舉辦中外各式婚宴"];
	[self createMapPoint:myMap2 
					  coordinateX:25.083606928081835 
					  coordinateY:121.55574917793274 
							Title:@"Wego" 
						 Subtitle:@"薇閣旅舍"];
	[self createMapPoint:myMap2 
					  coordinateX:25.08416079588206 
					  coordinateY:121.55746579170227 
							Title:@"維多利亞酒店" 
						 Subtitle:@"知名飯店 提供中西式餐點"];
	[self createMapPoint:myMap2 
					  coordinateX:25.08228540882096 
					  coordinateY:121.55800223350525 
							Title:@"家樂福" 
						 Subtitle:@"知名大型量販店"];
	[self createMapPoint:myMap2 
					  coordinateX:25.084850697882406 
					  coordinateY:121.55558824539185 
							Title:@"捷運劍南路站" 
						 Subtitle:@"MRT Station"];
	[self createMapPoint:myMap2 
					   coordinateX:25.078602570310615 
					   coordinateY:121.52626633644104 
							 Title:@"圓山大飯店" 
						  Subtitle:@"VTC Conference"];

/*	SFAnnotation *place1 = [[[SFAnnotation alloc] init ]autorelease];
	SFAnnotation *place2 = [[[SFAnnotation alloc] init ]autorelease];
	SFAnnotation *place3 = [[[SFAnnotation alloc] init ]autorelease];
	SFAnnotation *place4 = [[[SFAnnotation alloc] init ]autorelease];
	SFAnnotation *place5 = [[[SFAnnotation alloc] init ]autorelease];
	SFAnnotation *place6 = [[[SFAnnotation alloc] init ]autorelease];
	SFAnnotation *place7 = [[[SFAnnotation alloc] init ]autorelease];
	SFAnnotation *place8 = [[[SFAnnotation alloc] init ]autorelease];
	SFAnnotation *place9 = [[[SFAnnotation alloc] init ]autorelease];
	SFAnnotation *place10 = [[[SFAnnotation alloc] init ]autorelease];
	
	place1 = [self createMapPoint:myMap2 
					  coordinateX:25.063546878877353 
					  coordinateY:121.55214657064167 
							Title:@"松山機場" 
						 Subtitle:@"飛航國內與兩岸航班"];
	place2 = [self createMapPoint:myMap2 
					  coordinateX:25.054896374127832 
					  coordinateY:121.55742009489931 
							Title:@"松山醫院" 
						 Subtitle:@"醫院"];
	place3 = [self createMapPoint:myMap2 
					  coordinateX:25.033492284074082 
					  coordinateY:121.56422018047304 
							Title:@"台北 101" 
						 Subtitle:@"世界第二高樓"];
	place4 = [self createMapPoint:myMap2 
					  coordinateX:25.083754775873032 
					  coordinateY:121.55733263292502 
							Title:@"美麗華" 
						 Subtitle:@"摩天輪 IMAX影城"];
	place5 = [self createMapPoint:myMap2 
					  coordinateX:25.083606928081835 
					  coordinateY:121.55574917793274 
							Title:@"典華婚宴會場" 
						 Subtitle:@"舉辦中外各式婚宴"];
	place6 = [self createMapPoint:myMap2 
					  coordinateX:25.083606928081835 
					  coordinateY:121.55574917793274 
							Title:@"Wego" 
						 Subtitle:@"薇閣旅舍"];
	place7 = [self createMapPoint:myMap2 
					  coordinateX:25.08416079588206 
					  coordinateY:121.55746579170227 
							Title:@"維多利亞酒店" 
						 Subtitle:@"知名飯店 前主廚為阿基師"];
	place8 = [self createMapPoint:myMap2 
					  coordinateX:25.08228540882096 
					  coordinateY:121.55800223350525 
							Title:@"家樂福" 
						 Subtitle:@"知名大型量販店"];
	place9 = [self createMapPoint:myMap2 
					  coordinateX:25.084850697882406 
					  coordinateY:121.55558824539185 
							Title:@"捷運劍南路站" 
						 Subtitle:@"MRT Station"];
	place10 = [self createMapPoint:myMap2 
					  coordinateX:25.078602570310615 
					  coordinateY:121.52626633644104 
							Title:@"圓山大飯店" 
						 Subtitle:@"VTC Conference會場"];
	NSLog(@"point2");
	myPointArray = [[NSMutableArray  alloc] initWithCapacity:10];
	[myPointArray insertObject:place1 atIndex:0];
	NSLog(@"point3");
	[myPointArray insertObject:place2 atIndex:1];
	[myPointArray insertObject:place3 atIndex:2];
	[myPointArray insertObject:place4 atIndex:3];
	[myPointArray insertObject:place5 atIndex:4];
	[myPointArray insertObject:place6 atIndex:5];
	[myPointArray insertObject:place7 atIndex:6];
	[myPointArray insertObject:place8 atIndex:7];
	[myPointArray insertObject:place9 atIndex:8];
	[myPointArray insertObject:place10 atIndex:9];
*/
	NSLog(@"point over");
}

-(void)setMyMap{
	myMap2 =[[[MKMapView alloc] initWithFrame:CGRectMake(0,0,320,460)]autorelease];
	NSLog(@"%f",[[UIScreen mainScreen]description]);
	myMap2.mapType = MKMapTypeHybrid;
	myMap2.showsUserLocation = YES;
	
	//important!
	myMap2.delegate = self;
	
	//MKCoordinateRegion region2;
	
	//region2.center = myMap2.userLocation.coordinate;
	//美麗華
	//region2.center.latitude = 25.083754775873032;
	//region2.center.longitude = 121.55733263292502;
	
    MKCoordinateSpan span;
	
	span.latitudeDelta=.006;
	span.longitudeDelta=.006;
	
	region2.span = span;
	//zoom out by issac
	//region.span.latitudeDelta = region.span.latitudeDelta * 0.5;
	//region.span.longitudeDelta = region.span.longitudeDelta * 0.5;
	//[mylocationtest arrayWithObjects:];
	//MKPlacemark *placemark=[[MKPlacemark alloc] initWithCoordinate:region2.center];
	//mPlacemark = [MKPlacemark alloc];
	//[myMap2 addAnnotation:mPlacemark];
	//[self.myMap2 viewForAnnotation:place1];
	//[self.myMap2 viewForAnnotation:place1];
	
	[self setMyPoint];
	
	//[self.myMap2 addAnnotations:myPointArray];
/*	SFAnnotation *place1;

	CLLocationCoordinate2D p1;
	p1.latitude = 25.063546878877353;
	p1.longitude = 121.55214657064167;
	
	place1 = [[SFAnnotation alloc] initWithCoords:p1];

	[self.myMap2 addAnnotation:place1 ];
*/	NSLog(@"annotation 1");
	
	[self.myMap2 setRegion:region2 animated:YES];
	
	[self.view addSubview:myMap2];
}

// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
	[self setMyMap];
	[self settingLocationManager];
	//self.parentViewController.view = self.view ;
}



// Override to allow orientations other than the default portrait orientation.
//- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations
    //return (interfaceOrientation == UIInterfaceOrientationPortrait);
//}


- (void)didReceiveMemoryWarning {
	// Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
	
	// Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
	// Release any retained subviews of the main view.
	// e.g. self.myOutlet = nil;
	//[self dismissModalViewControllerAnimated:YES];
	self.myMap2 = nil;
}


- (void)dealloc {
	//[self dismissModalViewControllerAnimated:YES];
	[myMap2 release];
    [super dealloc];
}


@end
