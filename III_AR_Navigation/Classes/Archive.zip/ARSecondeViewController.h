//
//  ARSecondeViewController.h
//  III_AR_Navigation
//
//  Created by Chun F.Hsu on 2010/4/9.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MapKit/MapKit.h>
#import "SFAnnotation.h"

@interface ARSecondeViewController : UIViewController<CLLocationManagerDelegate, MKMapViewDelegate> {
	MKMapView *myMap2;
	CLLocationManager *locManager;
	CLLocationCoordinate2D updatedLocation;
	MKCoordinateRegion region2;
	NSMutableArray *myPointArray;
	//SFAnnotation *place1;
}
@property (nonatomic, retain) IBOutlet MKMapView *myMap2;
@property (nonatomic, retain) CLLocationManager *locManager;
//@property (nonatomic, retain) SFAnnotation *place1;
@property (nonatomic, retain) NSMutableArray *myPointArray;
//@property (nonatomic, retain) NSArray *mylocationtest;
@end
